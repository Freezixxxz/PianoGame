﻿namespace PP
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonPlay = new System.Windows.Forms.Button();
            this.buttonStats = new System.Windows.Forms.Button();
            this.labelGamesCount = new System.Windows.Forms.Label();
            this.labelTotalNotes = new System.Windows.Forms.Label();
            this.labelHighScore = new System.Windows.Forms.Label();
            this.labelLastPlay = new System.Windows.Forms.Label();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonPlay
            // 
            this.buttonPlay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.buttonPlay.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPlay.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonPlay.Location = new System.Drawing.Point(267, 288);
            this.buttonPlay.Name = "buttonPlay";
            this.buttonPlay.Size = new System.Drawing.Size(250, 60);
            this.buttonPlay.TabIndex = 2;
            this.buttonPlay.Text = "Играть";
            this.buttonPlay.UseVisualStyleBackColor = false;
            this.buttonPlay.Click += new System.EventHandler(this.buttonPlay_Click);
            // 
            // buttonStats
            // 
            this.buttonStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.buttonStats.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonStats.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonStats.Location = new System.Drawing.Point(267, 386);
            this.buttonStats.Name = "buttonStats";
            this.buttonStats.Size = new System.Drawing.Size(250, 50);
            this.buttonStats.TabIndex = 4;
            this.buttonStats.Text = "Статистика";
            this.buttonStats.UseVisualStyleBackColor = false;
            this.buttonStats.Click += new System.EventHandler(this.buttonStats_Click);
            // 
            // labelGamesCount
            // 
            this.labelGamesCount.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelGamesCount.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelGamesCount.Location = new System.Drawing.Point(12, 113);
            this.labelGamesCount.Name = "labelGamesCount";
            this.labelGamesCount.Size = new System.Drawing.Size(760, 52);
            this.labelGamesCount.TabIndex = 5;
            this.labelGamesCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTotalNotes
            // 
            this.labelTotalNotes.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTotalNotes.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelTotalNotes.Location = new System.Drawing.Point(12, 165);
            this.labelTotalNotes.Name = "labelTotalNotes";
            this.labelTotalNotes.Size = new System.Drawing.Size(760, 52);
            this.labelTotalNotes.TabIndex = 6;
            this.labelTotalNotes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelHighScore
            // 
            this.labelHighScore.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelHighScore.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelHighScore.Location = new System.Drawing.Point(12, 61);
            this.labelHighScore.Name = "labelHighScore";
            this.labelHighScore.Size = new System.Drawing.Size(760, 52);
            this.labelHighScore.TabIndex = 1;
            this.labelHighScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelLastPlay
            // 
            this.labelLastPlay.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelLastPlay.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelLastPlay.Location = new System.Drawing.Point(12, 217);
            this.labelLastPlay.Name = "labelLastPlay";
            this.labelLastPlay.Size = new System.Drawing.Size(760, 52);
            this.labelLastPlay.TabIndex = 7;
            this.labelLastPlay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelWelcome
            // 
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWelcome.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.labelWelcome.Location = new System.Drawing.Point(12, 9);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(760, 52);
            this.labelWelcome.TabIndex = 0;
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.labelWelcome);
            this.Controls.Add(this.labelLastPlay);
            this.Controls.Add(this.labelHighScore);
            this.Controls.Add(this.buttonStats);
            this.Controls.Add(this.labelTotalNotes);
            this.Controls.Add(this.labelGamesCount);
            this.Controls.Add(this.buttonPlay);
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuForm";
            this.Load += new System.EventHandler(this.MenuForm_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonPlay;
        private System.Windows.Forms.Button buttonStats;
        private System.Windows.Forms.Label labelGamesCount;
        private System.Windows.Forms.Label labelTotalNotes;
        private System.Windows.Forms.Label labelHighScore;
        private System.Windows.Forms.Label labelLastPlay;
        private System.Windows.Forms.Label labelWelcome;
    }
}