﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace PP
{
    public partial class PianoForm : Form
    {
        private int _currentSessionScore = 0;

        private SoundPlayer _player = new SoundPlayer();

        // ПЕРЕМЕННЫЕ ДЛЯ ИГРЫ
        private List<string> _gameSequence = new List<string>(); // Последовательность нот компьютера
        private int _playerIndex = 0; // Какую по счету ноту сейчас должен нажать игрок
        private bool _isGameActive = false; // Идет ли сейчас игра
        private bool _isPlayerTurn = false; // Сейчас очередь игрока?


        // Коллекция тональностей
        private string[][] _allScales = new string[][]
        {
            new string[] { "C4", "D4", "E4", "G4", "A4", "C5", "D5", "E5" }, 

            new string[] { "C4", "Dd4", "F4", "G4", "Ad4", "C5", "Dd5", "F5" },

            new string[] { "C4", "Cd4", "F4", "G4", "Gd4", "C5", "Cd5", "F5" }
        };

        // Переменная которая будет хранить текущий выбранный набор нот
        private string[] _currentRoundScale;

        private Random _rand = new Random();

        // Список для хранения зажатых клавиш
        private HashSet<Keys> _pressedKeys = new HashSet<Keys>();

        public PianoForm()
        {
            InitializeComponent();
            this.KeyPreview = true; 
            StyleButtons();
        }

        private void PlayNote(string noteName)
        {
            try
            {
                string path = @"C:\Users\evsee\source\repos\PP\PP\Assets\Piano\" + noteName + ".wav";

                _player.SoundLocation = path;

                _player.Load();

                _player.Play();

                if (GameData.CurrentUser != null)
                {
                    GameData.CurrentUser.TotalNotesPlayed++;
                }
                _currentSessionScore++;
                this.Text = "Пианино | Нажатий: " + GameData.CurrentUser.TotalNotesPlayed;
            }
            catch (Exception ex)
            {
                // Если файла нет
                MessageBox.Show("Ошибка звука: " + ex.Message);
            }
        }
        // Этот метод добавь в класс
        private void CheckPlayerInput(string notePlayed)
        {
            // Если игра не идет или сейчас ход компьютера - выходим
            if (!_isGameActive || !_isPlayerTurn) return;

            // Какую ноту надо было нажать?
            string expectedNote = _gameSequence[_playerIndex];

            if (notePlayed == expectedNote)
            {
                // УРА, ПРАВИЛЬНО
                _playerIndex++; // Ждем следующую ноту

                // Если игрок повторил ВСЮ последовательность
                if (_playerIndex >= _gameSequence.Count)
                {
                    this.Text = "Верно! Следующий раунд...";
                    _currentSessionScore = _gameSequence.Count; // Обновляем рекорд
                    StartNextRound(); // Запускаем новый круг
                }
            }
            else
            {
                // ОШИБКА - КОНЕЦ ИГРЫ
                GameOver();
            }
        }

        private void GameOver()
        {
            _isGameActive = false;

            int finalLevel = _gameSequence.Count; // Уровень = длина последовательности

            // 1. Обновляем данные пользователя
            GameData.CurrentUser.GamesPlayed += 1;
            GameData.CurrentUser.LastSession = DateTime.Now;

            // 2. Проверяем рекорд УРОВНЯ
            if (finalLevel > GameData.CurrentUser.HighScore)
            {
                GameData.CurrentUser.HighScore = finalLevel;
                MessageBox.Show($"Новый рекорд уровня: {finalLevel}!");
            }
            else
            {
                MessageBox.Show($"Игра окончена! Вы дошли до уровня: {finalLevel}");
            }

            // 3. Сохраняем всё в JSON
            GameData.SaveData();

            this.Close();
        }
        private void PianoForm_FormClosing(object sender, FormClosingEventArgs e)
        {
                GameData.SaveData();
        }

        private void btnC_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("C4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("C4");
        }
        private void btnD_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("D4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("D4");
        }
        private void btnE_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("E4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("E4");
        }
        private void btnF_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("F4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("F4");
        }
        private void btnG_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("G4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("G4");
        }
        private void btnA_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("A4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("A4");
        }
        private void btnB_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("B4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("B4");
        }

        private void btn_MouseUp(object sender, MouseEventArgs e)
        {
            Button btn = sender as Button;

            // Исключаем кнопку "Начать игру" из обработки
            if (btn.Name == "btnStartGame") return;

            // Остальной код без изменений
            if (btn.Name.Contains("d") == false)
            {
                btn.BackColor = Color.White;
            }
            else
            {
                btn.BackColor = Color.Black;
            }
        }



        private void btnCd4_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Cd4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Cd4");
        }

        private void btnDd4_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Dd4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Dd4");
        }
        private void btnFd4_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Fd4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Fd4");
        }
        private void btnGd4_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Gd4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Gd4");
        }
        private void btnAd4_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Ad4");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Ad4");
        }
        private void btnCd5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Cd5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Cd5");
        }
        private void btnDd5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Dd5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Dd5");
        }
        private void btnFd5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Fd5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Fd5");
        }
        private void btnGd5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Gd5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Gd5");
        }
        private void btnAd5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("Ad5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("Ad5");
        }

        private void btnC5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("C5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("C5");
        }
        private void btnD5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("D5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("D5");
        }
        private void btnE5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("E5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("E5");
        }
        private void btnF5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("F5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("F5");
        }
        private void btnG5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("G5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("G5");
        }
        private void btnA5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("A5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("A5");
        }
        private void btnB5_MouseDown(object sender, MouseEventArgs e)
        {
            PlayNote("B5");
            (sender as Button).BackColor = Color.LightGray;
            CheckPlayerInput("B5");
        }

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            _gameSequence.Clear(); // Очищаем старую мелодию
            _isGameActive = true;
            _currentSessionScore = 0; // В этой игре счет — это длина мелодии
            this.Text = "Слушайте мелодию...";

            // Генерируем случайный индекс от 0 до количества гамм (у нас их 3)
            int scaleIndex = _rand.Next(_allScales.Length);

            // Запоминаем выбранную гамму в переменную
            _currentRoundScale = _allScales[scaleIndex];

            string modeName = "";
            if (scaleIndex == 0) modeName = "Веселый режим";
            else if (scaleIndex == 1) modeName = "Блюз режим";
            else modeName = "Японский режим";

            this.Text = "Игра: " + modeName + ". Слушайте...";

            // Начинаем первый раунд (добавляем 1 ноту)
            StartNextRound();
        }
        private async void StartNextRound()
        {
            _isPlayerTurn = false; 
            _playerIndex = 0;

            // Добавляем новую случайную ноту к мелодии
            string newNote = _currentRoundScale[_rand.Next(_currentRoundScale.Length)];
            _gameSequence.Add(newNote);

            // Проигрываем всю мелодию игроку
            // Делаем паузу перед началом
            await Task.Delay(1000);

            foreach (string note in _gameSequence)
            {
                // Важно: имя кнопки должно быть "btn" + название ноты (например, btnC1)
                string buttonName = "btn" + note;
                Control[] found = this.Controls.Find(buttonName, true);

                if (found.Length > 0 && found[0] is Button btn)
                {
                    // Подсветка желтым
                    Color oldColor = btn.BackColor;
                    btn.BackColor = Color.Yellow;

                    // Звук
                    PlayNote(note);

                    // Ждем 500мс (длительность ноты)
                    await Task.Delay(500);

                    // Возвращаем цвет
                    btn.BackColor = oldColor;

                    // Пауза между нотами
                    await Task.Delay(200);
                }
            }

            // 3. Передаем ход игроку
            _isPlayerTurn = true;
            this.Text = "Повторите мелодию! (Уровень " + _gameSequence.Count + ")";
        }

        private void PianoForm_KeyDown(object sender, KeyEventArgs e)
        {

            if (_pressedKeys.Contains(e.KeyCode)) return;

            // Добавляем клавишу в список зажатых
            _pressedKeys.Add(e.KeyCode);

            switch (e.KeyCode)
            {
                // --- ПЕРВАЯ ОКТАВА ---
                case Keys.Z: btnC_MouseDown(btnC4, null); break; 
                case Keys.S: btnCd4_MouseDown(btnCd4, null); break;
                case Keys.X: btnD_MouseDown(btnD4, null); break;
                case Keys.D: btnDd4_MouseDown(btnDd4, null); break;
                case Keys.C: btnE_MouseDown(btnE4, null); break;  
                case Keys.V: btnF_MouseDown(btnF4, null); break;   
                case Keys.G: btnFd4_MouseDown(btnFd4, null); break;
                case Keys.B: btnG_MouseDown(btnG4, null); break;
                case Keys.H: btnGd4_MouseDown(btnGd4, null); break; 
                case Keys.N: btnA_MouseDown(btnA4, null); break;  
                case Keys.J: btnAd4_MouseDown(btnAd4, null); break; 
                case Keys.M: btnB_MouseDown(btnB4, null); break;   

                // --- ВТОРАЯ ОКТАВА ---
                case Keys.Q: btnC5_MouseDown(btnC5, null); break;  
                case Keys.D2: btnCd5_MouseDown(btnCd5, null); break; 
                case Keys.W: btnD5_MouseDown(btnD5, null); break;  
                case Keys.D3: btnDd5_MouseDown(btnDd5, null); break;  
                case Keys.E: btnE5_MouseDown(btnE5, null); break;    
                case Keys.R: btnF5_MouseDown(btnF5, null); break;      
                case Keys.D5: btnFd5_MouseDown(btnFd5, null); break;  
                case Keys.T: btnG5_MouseDown(btnG5, null); break;      
                case Keys.D6: btnGd5_MouseDown(btnGd5, null); break;  
                case Keys.Y: btnA5_MouseDown(btnA5, null); break;      
                case Keys.D7: btnAd5_MouseDown(btnAd5, null); break;  
                case Keys.U: btnB5_MouseDown(btnB5, null); break;     
            }
        }
        private void StyleButtons()
        {
            foreach (Control c in this.Controls)
            {
                if (c is Button btn)
                {
                    btn.Cursor = Cursors.Hand;
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 1;

                    // Запоминаем исходный цвет кнопки в Tag программно, 
                    // чтобы потом точно знать, какой цвет возвращать
                    btn.Tag = btn.BackColor;

                    // Эффект при наведении
                    btn.MouseEnter += (s, e) => {
                        if (btn.BackColor == Color.White || btn.BackColor == Color.WhiteSmoke)
                            btn.BackColor = Color.Gainsboro;
                        else
                            btn.BackColor = Color.FromArgb(70, 70, 70);
                    };

                    // Эффект при уходе мышки
                    btn.MouseLeave += (s, e) => {
                        // Возвращаем тот цвет, который мы запомнили в самом начале
                        btn.BackColor = (Color)btn.Tag;
                    };
                }
            }
        }
        private void PianoForm_KeyUp(object sender, KeyEventArgs e)
        {
            // Когда отпускаем любую клавишу, возвращаем цвета всем кнопкам

            if (_pressedKeys.Contains(e.KeyCode))
            {
                _pressedKeys.Remove(e.KeyCode);
            }
            foreach (Control c in this.Controls)
            {
                if (c is Button btn)
                {
                    btn_MouseUp(btn, null);
                }
            }
        }


    }

}
