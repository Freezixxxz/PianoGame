﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP
{
    public class User
    {
        public string Name { get; set; }
        public int HighScore { get; set; }

        public User() { }

        public int GamesPlayed { get; set; }   // Сколько всего раз нажал Играть
        public int TotalNotesPlayed { get; set; } // Сколько всего нот нажал за всё время
        public DateTime LastSession { get; set; } // Дата последней игры

        public User(string name)
        {
            Name = name;
            HighScore = 0;
            TotalNotesPlayed = 0;
            LastSession = DateTime.Now;
        }
    }
}