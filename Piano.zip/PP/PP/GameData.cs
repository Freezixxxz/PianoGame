﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json; // Если подчеркивает красным, читай примечание ниже*
using System.Windows.Forms;

namespace PP
{
    public static class GameData
    {
        public static List<User> Users = new List<User>();

        public static User CurrentUser;

        private static string _filePath = "users.json";

        public static void LoadData()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    string json = File.ReadAllText(_filePath);

                    // ПРОВЕРКА: Если файл пустой или состоит только из пробелов
                    if (string.IsNullOrWhiteSpace(json))
                    {
                        Users = new List<User>();
                        return;
                    }

                    // Пытаемся десериализовать
                    Users = JsonSerializer.Deserialize<List<User>>(json);

                    // Если вдруг в файле было что-то странное и Users стал null
                    if (Users == null) Users = new List<User>();
                }
                else
                {
                    Users = new List<User>();
                }
            }
            catch (Exception ex)
            {
                // Если файл поврежден, создаем новый пустой список
                // чтобы программа не вылетала
                Users = new List<User>();
                MessageBox.Show("Ошибка при загрузке данных. Создан новый список.");
            }
        }
        public static void SaveData()
        {
            // Превращаем список пользователей в красивый текст
            string json = JsonSerializer.Serialize(Users);
            File.WriteAllText(_filePath, json);
        }
        public static void LoginUser(string name)
        {
            // Ищем, есть ли уже такой пользователь в списке
            // (Is.Name == name) — это условие поиска
            var foundUser = Users.FirstOrDefault(u => u.Name == name);

            if (foundUser != null)
            {
                // Если нашли - запоминаем его как текущего
                CurrentUser = foundUser;
            }
            else
            {
                // Если не нашли - создаем нового и добавляем в список
                User newUser = new User(name);
                Users.Add(newUser);
                CurrentUser = newUser;
            }
        }
    }
}
