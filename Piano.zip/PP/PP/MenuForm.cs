﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP
{
    public partial class MenuForm : Form
    {

        private string _userName;

        private bool _isDarkTheme = false;

        public MenuForm()
        {
            InitializeComponent();
            this.Load += MenuForm_Load;
        }

        private void MenuForm_Load(object sender, EventArgs e)
        {
            UpdateStats();
        }
        public void UpdateStats()
        {
            if (GameData.CurrentUser != null)
            {
                UpdateStatsDisplay(); // Вызываем метод отрисовки данных
                labelWelcome.Text = "Привет, " + GameData.CurrentUser.Name;
                // Предположим у тебя есть labelStats
                // labelStats.Text = "Рекорд нажатий: " + GameData.CurrentUser.HighScore;
            }
        }

        private void buttonPlay_Click(object sender, EventArgs e)
        {
            PianoForm piano = new PianoForm();
            this.Hide();
            piano.ShowDialog();

            // Когда пианино закроется, код продолжится здесь:
            this.Show();
            // Обновляем статистику, вдруг мы поставили новый рекорд
            UpdateStats();
        }


        private void buttonStats_Click(object sender, EventArgs e)
        {
            // Создаем окно статистики
            StatsForm stats = new StatsForm();

            // Показываем его как модальное окно (поверх меню)
            stats.ShowDialog();
        }

        public void UpdateStatsDisplay()
        {
            var user = GameData.CurrentUser;
            if (user != null)
            {
                labelWelcome.Text = $"Привет, {user.Name}!";
                labelHighScore.Text = $"Рекорд (уровень): {user.HighScore}";
                labelGamesCount.Text = $"Всего игр: {user.GamesPlayed}";
                labelTotalNotes.Text = $"Всего нажато нот: {user.TotalNotesPlayed}";
                labelLastPlay.Text = $"Последний раз: {user.LastSession.ToShortDateString()}";
            }
        }

    }
}
