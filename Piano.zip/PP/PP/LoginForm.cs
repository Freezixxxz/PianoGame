﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            GameData.LoadData();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string userName = textBoxName.Text;

            if (string.IsNullOrWhiteSpace(userName))
            {
                MessageBox.Show("Пожалуйста, введите имя!", "Ошибка");
                return;
            }
            // Регистрируем или находим пользователя через наш новый класс
            GameData.LoginUser(userName);

            MenuForm menu = new MenuForm();
            this.Hide();
            menu.ShowDialog();
            this.Close();
        }
    }
}
