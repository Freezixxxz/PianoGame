﻿namespace PP
{
    partial class PianoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnC4 = new System.Windows.Forms.Button();
            this.btnD4 = new System.Windows.Forms.Button();
            this.btnE4 = new System.Windows.Forms.Button();
            this.btnF4 = new System.Windows.Forms.Button();
            this.btnG4 = new System.Windows.Forms.Button();
            this.btnA4 = new System.Windows.Forms.Button();
            this.btnB4 = new System.Windows.Forms.Button();
            this.btnG5 = new System.Windows.Forms.Button();
            this.btnA5 = new System.Windows.Forms.Button();
            this.btnB5 = new System.Windows.Forms.Button();
            this.btnE5 = new System.Windows.Forms.Button();
            this.btnF5 = new System.Windows.Forms.Button();
            this.btnD5 = new System.Windows.Forms.Button();
            this.btnC5 = new System.Windows.Forms.Button();
            this.btnCd4 = new System.Windows.Forms.Button();
            this.btnDd4 = new System.Windows.Forms.Button();
            this.btnFd4 = new System.Windows.Forms.Button();
            this.btnGd4 = new System.Windows.Forms.Button();
            this.btnAd4 = new System.Windows.Forms.Button();
            this.btnAd5 = new System.Windows.Forms.Button();
            this.btnGd5 = new System.Windows.Forms.Button();
            this.btnFd5 = new System.Windows.Forms.Button();
            this.btnDd5 = new System.Windows.Forms.Button();
            this.btnCd5 = new System.Windows.Forms.Button();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btnC4
            // 
            this.btnC4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnC4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnC4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnC4.Location = new System.Drawing.Point(48, 149);
            this.btnC4.Name = "btnC4";
            this.btnC4.Size = new System.Drawing.Size(50, 200);
            this.btnC4.TabIndex = 0;
            this.btnC4.Text = "До";
            this.btnC4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnC4.UseVisualStyleBackColor = false;
            this.btnC4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnC4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnC4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnC_MouseDown);
            this.btnC4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnD4
            // 
            this.btnD4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnD4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnD4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnD4.Location = new System.Drawing.Point(98, 149);
            this.btnD4.Name = "btnD4";
            this.btnD4.Size = new System.Drawing.Size(50, 200);
            this.btnD4.TabIndex = 1;
            this.btnD4.Text = "Ре";
            this.btnD4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnD4.UseVisualStyleBackColor = false;
            this.btnD4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnD4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnD4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnD_MouseDown);
            this.btnD4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnE4
            // 
            this.btnE4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnE4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnE4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnE4.Location = new System.Drawing.Point(148, 149);
            this.btnE4.Name = "btnE4";
            this.btnE4.Size = new System.Drawing.Size(50, 200);
            this.btnE4.TabIndex = 3;
            this.btnE4.Text = "Ми";
            this.btnE4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnE4.UseVisualStyleBackColor = false;
            this.btnE4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnE4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnE4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnE_MouseDown);
            this.btnE4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnF4
            // 
            this.btnF4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnF4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnF4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnF4.Location = new System.Drawing.Point(198, 149);
            this.btnF4.Name = "btnF4";
            this.btnF4.Size = new System.Drawing.Size(50, 200);
            this.btnF4.TabIndex = 2;
            this.btnF4.Text = "Фа";
            this.btnF4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnF4.UseVisualStyleBackColor = false;
            this.btnF4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnF4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnF4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnF_MouseDown);
            this.btnF4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnG4
            // 
            this.btnG4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnG4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnG4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnG4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnG4.Location = new System.Drawing.Point(248, 149);
            this.btnG4.Name = "btnG4";
            this.btnG4.Size = new System.Drawing.Size(50, 200);
            this.btnG4.TabIndex = 6;
            this.btnG4.Text = "Соль";
            this.btnG4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnG4.UseVisualStyleBackColor = false;
            this.btnG4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnG4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnG4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnG_MouseDown);
            this.btnG4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnA4
            // 
            this.btnA4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnA4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnA4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnA4.Location = new System.Drawing.Point(298, 149);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(50, 200);
            this.btnA4.TabIndex = 5;
            this.btnA4.Text = "Ля";
            this.btnA4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnA4.UseVisualStyleBackColor = false;
            this.btnA4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnA4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnA4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnA_MouseDown);
            this.btnA4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnB4
            // 
            this.btnB4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnB4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnB4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnB4.Location = new System.Drawing.Point(348, 149);
            this.btnB4.Name = "btnB4";
            this.btnB4.Size = new System.Drawing.Size(50, 200);
            this.btnB4.TabIndex = 4;
            this.btnB4.Text = "Си";
            this.btnB4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnB4.UseVisualStyleBackColor = false;
            this.btnB4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnB4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnB4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnB_MouseDown);
            this.btnB4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnG5
            // 
            this.btnG5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnG5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnG5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnG5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnG5.Location = new System.Drawing.Point(598, 149);
            this.btnG5.Name = "btnG5";
            this.btnG5.Size = new System.Drawing.Size(50, 200);
            this.btnG5.TabIndex = 13;
            this.btnG5.Text = "Соль";
            this.btnG5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnG5.UseVisualStyleBackColor = false;
            this.btnG5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnG5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnG5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnG5_MouseDown);
            this.btnG5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnA5
            // 
            this.btnA5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnA5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnA5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnA5.Location = new System.Drawing.Point(648, 149);
            this.btnA5.Name = "btnA5";
            this.btnA5.Size = new System.Drawing.Size(50, 200);
            this.btnA5.TabIndex = 12;
            this.btnA5.Text = "Ля";
            this.btnA5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnA5.UseVisualStyleBackColor = false;
            this.btnA5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnA5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnA5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnA5_MouseDown);
            this.btnA5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnB5
            // 
            this.btnB5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnB5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnB5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnB5.Location = new System.Drawing.Point(698, 149);
            this.btnB5.Name = "btnB5";
            this.btnB5.Size = new System.Drawing.Size(50, 200);
            this.btnB5.TabIndex = 11;
            this.btnB5.Text = "Си";
            this.btnB5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnB5.UseVisualStyleBackColor = false;
            this.btnB5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnB5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnB5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnB5_MouseDown);
            this.btnB5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnE5
            // 
            this.btnE5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnE5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnE5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnE5.Location = new System.Drawing.Point(498, 149);
            this.btnE5.Name = "btnE5";
            this.btnE5.Size = new System.Drawing.Size(50, 200);
            this.btnE5.TabIndex = 10;
            this.btnE5.Text = "Ми";
            this.btnE5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnE5.UseVisualStyleBackColor = false;
            this.btnE5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnE5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnE5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnE5_MouseDown);
            this.btnE5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnF5
            // 
            this.btnF5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnF5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnF5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnF5.Location = new System.Drawing.Point(548, 149);
            this.btnF5.Name = "btnF5";
            this.btnF5.Size = new System.Drawing.Size(50, 200);
            this.btnF5.TabIndex = 9;
            this.btnF5.Text = "Фа";
            this.btnF5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnF5.UseVisualStyleBackColor = false;
            this.btnF5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnF5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnF5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnF5_MouseDown);
            this.btnF5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnD5
            // 
            this.btnD5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnD5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnD5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnD5.Location = new System.Drawing.Point(448, 149);
            this.btnD5.Name = "btnD5";
            this.btnD5.Size = new System.Drawing.Size(50, 200);
            this.btnD5.TabIndex = 8;
            this.btnD5.Text = "Ре";
            this.btnD5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnD5.UseVisualStyleBackColor = false;
            this.btnD5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnD5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnD5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnD5_MouseDown);
            this.btnD5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnC5
            // 
            this.btnC5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnC5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.btnC5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnC5.Location = new System.Drawing.Point(398, 149);
            this.btnC5.Name = "btnC5";
            this.btnC5.Size = new System.Drawing.Size(50, 200);
            this.btnC5.TabIndex = 7;
            this.btnC5.Text = "До";
            this.btnC5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnC5.UseVisualStyleBackColor = false;
            this.btnC5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnC5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnC5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnC5_MouseDown);
            this.btnC5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnCd4
            // 
            this.btnCd4.BackColor = System.Drawing.Color.Black;
            this.btnCd4.FlatAppearance.BorderSize = 0;
            this.btnCd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCd4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCd4.ForeColor = System.Drawing.Color.White;
            this.btnCd4.Location = new System.Drawing.Point(83, 149);
            this.btnCd4.Name = "btnCd4";
            this.btnCd4.Size = new System.Drawing.Size(30, 120);
            this.btnCd4.TabIndex = 14;
            this.btnCd4.Tag = "Black";
            this.btnCd4.Text = "До#";
            this.btnCd4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCd4.UseVisualStyleBackColor = false;
            this.btnCd4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnCd4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnCd4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnCd4_MouseDown);
            this.btnCd4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnDd4
            // 
            this.btnDd4.BackColor = System.Drawing.Color.Black;
            this.btnDd4.FlatAppearance.BorderSize = 0;
            this.btnDd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDd4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDd4.ForeColor = System.Drawing.Color.White;
            this.btnDd4.Location = new System.Drawing.Point(133, 149);
            this.btnDd4.Name = "btnDd4";
            this.btnDd4.Size = new System.Drawing.Size(30, 120);
            this.btnDd4.TabIndex = 15;
            this.btnDd4.Tag = "Black";
            this.btnDd4.Text = "Ре#";
            this.btnDd4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDd4.UseVisualStyleBackColor = false;
            this.btnDd4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnDd4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnDd4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnDd4_MouseDown);
            this.btnDd4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnFd4
            // 
            this.btnFd4.BackColor = System.Drawing.Color.Black;
            this.btnFd4.FlatAppearance.BorderSize = 0;
            this.btnFd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFd4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFd4.ForeColor = System.Drawing.Color.White;
            this.btnFd4.Location = new System.Drawing.Point(233, 149);
            this.btnFd4.Name = "btnFd4";
            this.btnFd4.Size = new System.Drawing.Size(30, 120);
            this.btnFd4.TabIndex = 16;
            this.btnFd4.Tag = "Black";
            this.btnFd4.Text = "Фа#";
            this.btnFd4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFd4.UseVisualStyleBackColor = false;
            this.btnFd4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnFd4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnFd4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnFd4_MouseDown);
            this.btnFd4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnGd4
            // 
            this.btnGd4.BackColor = System.Drawing.Color.Black;
            this.btnGd4.FlatAppearance.BorderSize = 0;
            this.btnGd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGd4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnGd4.ForeColor = System.Drawing.Color.White;
            this.btnGd4.Location = new System.Drawing.Point(283, 149);
            this.btnGd4.Name = "btnGd4";
            this.btnGd4.Size = new System.Drawing.Size(30, 120);
            this.btnGd4.TabIndex = 17;
            this.btnGd4.Tag = "Black";
            this.btnGd4.Text = "Соль#";
            this.btnGd4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGd4.UseVisualStyleBackColor = false;
            this.btnGd4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnGd4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnGd4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnGd4_MouseDown);
            this.btnGd4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnAd4
            // 
            this.btnAd4.BackColor = System.Drawing.Color.Black;
            this.btnAd4.FlatAppearance.BorderSize = 0;
            this.btnAd4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAd4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAd4.ForeColor = System.Drawing.Color.White;
            this.btnAd4.Location = new System.Drawing.Point(333, 149);
            this.btnAd4.Name = "btnAd4";
            this.btnAd4.Size = new System.Drawing.Size(30, 120);
            this.btnAd4.TabIndex = 18;
            this.btnAd4.Tag = "Black";
            this.btnAd4.Text = "Ля#";
            this.btnAd4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAd4.UseVisualStyleBackColor = false;
            this.btnAd4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnAd4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnAd4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAd4_MouseDown);
            this.btnAd4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnAd5
            // 
            this.btnAd5.BackColor = System.Drawing.Color.Black;
            this.btnAd5.FlatAppearance.BorderSize = 0;
            this.btnAd5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAd5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAd5.ForeColor = System.Drawing.Color.White;
            this.btnAd5.Location = new System.Drawing.Point(683, 149);
            this.btnAd5.Name = "btnAd5";
            this.btnAd5.Size = new System.Drawing.Size(30, 120);
            this.btnAd5.TabIndex = 23;
            this.btnAd5.Tag = "Black";
            this.btnAd5.Text = "Ля#";
            this.btnAd5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAd5.UseVisualStyleBackColor = false;
            this.btnAd5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnAd5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnAd5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnAd5_MouseDown);
            this.btnAd5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnGd5
            // 
            this.btnGd5.BackColor = System.Drawing.Color.Black;
            this.btnGd5.FlatAppearance.BorderSize = 0;
            this.btnGd5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGd5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnGd5.ForeColor = System.Drawing.Color.White;
            this.btnGd5.Location = new System.Drawing.Point(633, 149);
            this.btnGd5.Name = "btnGd5";
            this.btnGd5.Size = new System.Drawing.Size(30, 120);
            this.btnGd5.TabIndex = 22;
            this.btnGd5.Tag = "Black";
            this.btnGd5.Text = "Соль#";
            this.btnGd5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGd5.UseVisualStyleBackColor = false;
            this.btnGd5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnGd5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnGd5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnGd5_MouseDown);
            this.btnGd5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnFd5
            // 
            this.btnFd5.BackColor = System.Drawing.Color.Black;
            this.btnFd5.FlatAppearance.BorderSize = 0;
            this.btnFd5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFd5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFd5.ForeColor = System.Drawing.Color.White;
            this.btnFd5.Location = new System.Drawing.Point(583, 149);
            this.btnFd5.Name = "btnFd5";
            this.btnFd5.Size = new System.Drawing.Size(30, 120);
            this.btnFd5.TabIndex = 21;
            this.btnFd5.Tag = "Black";
            this.btnFd5.Text = "Фа#";
            this.btnFd5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFd5.UseVisualStyleBackColor = false;
            this.btnFd5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnFd5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnFd5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnFd5_MouseDown);
            this.btnFd5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnDd5
            // 
            this.btnDd5.BackColor = System.Drawing.Color.Black;
            this.btnDd5.FlatAppearance.BorderSize = 0;
            this.btnDd5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDd5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDd5.ForeColor = System.Drawing.Color.White;
            this.btnDd5.Location = new System.Drawing.Point(483, 149);
            this.btnDd5.Name = "btnDd5";
            this.btnDd5.Size = new System.Drawing.Size(30, 120);
            this.btnDd5.TabIndex = 20;
            this.btnDd5.Tag = "Black";
            this.btnDd5.Text = "Ре#";
            this.btnDd5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDd5.UseVisualStyleBackColor = false;
            this.btnDd5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnDd5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnDd5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnDd5_MouseDown);
            this.btnDd5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnCd5
            // 
            this.btnCd5.BackColor = System.Drawing.Color.Black;
            this.btnCd5.FlatAppearance.BorderSize = 0;
            this.btnCd5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCd5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCd5.ForeColor = System.Drawing.Color.White;
            this.btnCd5.Location = new System.Drawing.Point(433, 149);
            this.btnCd5.Name = "btnCd5";
            this.btnCd5.Size = new System.Drawing.Size(30, 120);
            this.btnCd5.TabIndex = 19;
            this.btnCd5.Tag = "Black";
            this.btnCd5.Text = "До#";
            this.btnCd5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCd5.UseVisualStyleBackColor = false;
            this.btnCd5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.btnCd5.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyUp);
            this.btnCd5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnCd5_MouseDown);
            this.btnCd5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_MouseUp);
            // 
            // btnStartGame
            // 
            this.btnStartGame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnStartGame.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStartGame.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnStartGame.Location = new System.Drawing.Point(298, 43);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(198, 54);
            this.btnStartGame.TabIndex = 24;
            this.btnStartGame.Text = "Начать игру";
            this.btnStartGame.UseVisualStyleBackColor = false;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(40, 140);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(716, 217);
            this.panel1.TabIndex = 25;
            // 
            // PianoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(794, 361);
            this.Controls.Add(this.btnAd5);
            this.Controls.Add(this.btnGd5);
            this.Controls.Add(this.btnFd5);
            this.Controls.Add(this.btnDd5);
            this.Controls.Add(this.btnCd5);
            this.Controls.Add(this.btnAd4);
            this.Controls.Add(this.btnGd4);
            this.Controls.Add(this.btnFd4);
            this.Controls.Add(this.btnDd4);
            this.Controls.Add(this.btnCd4);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.btnG5);
            this.Controls.Add(this.btnA5);
            this.Controls.Add(this.btnB5);
            this.Controls.Add(this.btnE5);
            this.Controls.Add(this.btnF5);
            this.Controls.Add(this.btnD5);
            this.Controls.Add(this.btnC5);
            this.Controls.Add(this.btnG4);
            this.Controls.Add(this.btnA4);
            this.Controls.Add(this.btnB4);
            this.Controls.Add(this.btnE4);
            this.Controls.Add(this.btnF4);
            this.Controls.Add(this.btnD4);
            this.Controls.Add(this.btnC4);
            this.Controls.Add(this.panel1);
            this.KeyPreview = true;
            this.Name = "PianoForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PianoForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PianoForm_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PianoForm_KeyDown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnC4;
        private System.Windows.Forms.Button btnD4;
        private System.Windows.Forms.Button btnE4;
        private System.Windows.Forms.Button btnF4;
        private System.Windows.Forms.Button btnG4;
        private System.Windows.Forms.Button btnA4;
        private System.Windows.Forms.Button btnB4;
        private System.Windows.Forms.Button btnG5;
        private System.Windows.Forms.Button btnA5;
        private System.Windows.Forms.Button btnB5;
        private System.Windows.Forms.Button btnE5;
        private System.Windows.Forms.Button btnF5;
        private System.Windows.Forms.Button btnD5;
        private System.Windows.Forms.Button btnC5;
        private System.Windows.Forms.Button btnCd4;
        private System.Windows.Forms.Button btnDd4;
        private System.Windows.Forms.Button btnFd4;
        private System.Windows.Forms.Button btnGd4;
        private System.Windows.Forms.Button btnAd4;
        private System.Windows.Forms.Button btnAd5;
        private System.Windows.Forms.Button btnGd5;
        private System.Windows.Forms.Button btnFd5;
        private System.Windows.Forms.Button btnDd5;
        private System.Windows.Forms.Button btnCd5;
        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.Panel panel1;
    }
}