﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP
{
    public partial class StatsForm : Form
    {
        public StatsForm()
        {
            InitializeComponent();
            LoadLeaderboard();
        }
        private void LoadLeaderboard()
        {
            listBoxLeaders.Items.Clear();

            // Сортируем пользователей по HighScore (сверху самые крутые)
            // OrderByDescending делает сортировку от большего к меньшему
            var sortedUsers = GameData.Users
                .OrderByDescending(u => u.HighScore)
                .ToList();

            int rank = 1;
            foreach (var user in sortedUsers)
            {
                // Формируем красивую строку для списка
                string info = $"{rank}. {user.Name} — Рекорд: {user.HighScore} (Всего кликов: {user.TotalNotesPlayed})";
                listBoxLeaders.Items.Add(info);
                rank++;
            }

        }

    }
}
